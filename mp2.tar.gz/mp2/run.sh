killall ls_router
./ls_router 0 example_topology/test2initcosts0 log0 &
./ls_router 1 example_topology/test2initcosts1 log1 &
./ls_router 2 example_topology/test2initcosts2 log2 &
./ls_router 3 example_topology/test2initcosts3 log3 &
./ls_router 4 example_topology/test2initcosts4 log4 &
./ls_router 5 example_topology/test2initcosts5 log5 &
./ls_router 6 example_topology/test2initcosts6 log6 &
./ls_router 7 example_topology/test2initcosts7 log7 &
./ls_router 255 example_topology/test2initcosts255 log255 &
sleep 2000
